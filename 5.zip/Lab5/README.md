П'ята лабораторна ASP.Net Razor Pages з Entity Framework
